public class Start{
	public static void main(String args[]){
		Select s=new Select();
		s.setVisible(true);
	}
}